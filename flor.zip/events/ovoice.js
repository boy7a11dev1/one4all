const { Client, GatewayIntentBits } = require('discord.js');
const { joinVoiceChannel, VoiceConnectionStatus, createAudioPlayer } = require('@discordjs/voice');

// إنشاء عميل ديسكورد جديد
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent
    ]
});

// متغير لتخزين الاتصال الصوتي الحالي
let currentConnection = null;

// حدث عند جاهزية البوت
client.on('ready', () => {
    console.log(`✅ البوت يعمل باسم: ${client.user.tag}`);
});

// دالة للاتصال بقناة الصوت
async function connectToVoiceChannel(channelId) {
    try {
        // 1. جلب معلومات القناة من ديسكورد
        const voiceChannel = await client.channels.fetch(channelId).catch(() => null);
        
        if (!voiceChannel) {
            throw new Error('القناة غير موجودة أو لا يمكن الوصول إليها');
        }

        if (voiceChannel.type !== 2) { // 2 = GUILD_VOICE
            throw new Error('هذه ليست قناة صوتية صالحة');
        }

        // 2. إنشاء اتصال صوتي جديد
        const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: voiceChannel.guild.id,
            adapterCreator: voiceChannel.guild.voiceAdapterCreator,
            selfDeaf: false,
            selfMute: false
        });

        // 3. إنشاء مشغل صوت
        const player = createAudioPlayer();
        connection.subscribe(player);

        // 4. إعداد معالجات الأحداث
        connection.on(VoiceConnectionStatus.Ready, () => {
            console.log(`✅ اتصل بنجاح بقناة: ${voiceChannel.name}`);
        });

        connection.on(VoiceConnectionStatus.Disconnected, async () => {
            try {
                connection.destroy();
                currentConnection = null;
                console.log('❌ تم قطع الاتصال');
            } catch (error) {
                console.error('خطأ في قطع الاتصال:', error);
            }
        });

        connection.on('error', error => {
            console.error('⚠️ خطأ في الاتصال الصوتي:', error);
        });

        currentConnection = connection;
        return connection;

    } catch (error) {
        console.error('❌ فشل الاتصال:', error.message);
        return null;
    }
}

// دالة لمغادرة القناة الصوتية
function disconnectFromVoice() {
    if (currentConnection) {
        currentConnection.destroy();
        currentConnection = null;
        console.log('✅ غادر القناة الصوتية');
        return true;
    }
    console.log('⚠️ لا يوجد اتصال صوتي نشط');
    return false;
}

// معالجة الأوامر النصية
client.on('messageCreate', async message => {
    if (message.author.bot) return;

    if (message.content.startsWith('join')) {
        const channelId = message.content.split(' ')[1] || message.member?.voice?.channelId;
        
        if (!channelId) {
            return message.reply('⚠️ الرجاء تحديد قناة صوتية أو الانضمام إلى واحدة أولاً!');
        }

        const connection = await connectToVoiceChannel(channelId);
        message.reply(connection ? '✅ تم الانضمام للقناة!' : '❌ فشل الانضمام!');
    }

    if (message.content === 'leave') {
        const success = disconnectFromVoice();
        message.reply(success ? '✅ غادرت القناة!' : '⚠️ لا يوجد اتصال صوتي نشط');
    }
});

// تسجيل الدخول باستخدام التوكن
client.login('token')
    .then(() => console.log('🚀 بدأ تشغيل البوت...'))
    .catch(error => console.error('❌ فشل تسجيل الدخول:', error));