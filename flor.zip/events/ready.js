const { Client, ActivityType, Events } = require("discord.js");

module.exports = {
    name: Events.ClientReady,
    once: true,
    /**
     * @param {Client} client
     */
    execute(client) {
        client.user.setPresence({
            status: 'dnd', // 'online' | 'idle' | 'dnd' | 'invisible'
            activities: [{
                name: 'Elite',
                type: ActivityType.Streaming, // Playing | Streaming | Listening | Watching | Custom
                url: 'https://www.twitch.tv/boy7a11' // ضروري فقط إذا نوع النشاط Streaming
            }]
        });

        console.log(`Bot is now online as ${client.user.tag}`);
    },
};
