const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const { Database } = require("st.db");
const feedbackDB = new Database("/Json-db/Bots/feedbackDB.json");

module.exports = {
    adminsOnly: true,
    data: new SlashCommandBuilder()
        .setName('delete-feedback-room')
        .setDescription('حذف روم الآراء المحدد'),
    
    async execute(interaction) {
        try {
            // التحقق من وجود روم فيدباك مسجل أصلاً
            const currentRoom = feedbackDB.get(`feedback_room_${interaction.guild.id}`);
            
            if (!currentRoom) {
                return interaction.reply({
                    content: "⚠️ لا يوجد روم آراء محدد مسبقاً!",
                    ephemeral: true
                });
            }

            // حذف روم الفيدباك من قاعدة البيانات
            await feedbackDB.delete(`feedback_room_${interaction.guild.id}`);
            
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('تم حذف روم الآراء بنجاح')
                .setDescription(`تم إزالة روم الآراء المحدد من النظام`)
                .setTimestamp();

            return interaction.reply({
                embeds: [embed],
                ephemeral: true
            });

        } catch (error) {
            console.error('حدث خطأ أثناء حذف روم الآراء:', error);
            return interaction.reply({
                content: "❌ حدث خطأ أثناء محاولة حذف روم الآراء!",
                ephemeral: true
            });
        }
    }
}