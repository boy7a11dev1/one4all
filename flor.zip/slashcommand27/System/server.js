const { SlashCommandBuilder, ChannelType, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");
const systemDB = new Database("./Json-db/Bots/systemDB.json"); // Fixed path

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('server')
        .setDescription('رؤية معلومات السيرفر'),
    
    async execute(interaction) {
        try {
            await interaction.deferReply({ ephemeral: false });
            
            if (!interaction.guild) {
                return interaction.editReply({ content: "❌ هذا الأمر يمكن استخدامه فقط داخل السيرفرات!" });
            }

            const guild = interaction.guild;
            const owner = await guild.fetchOwner();
            
            // Format verification level
            const verificationLevels = {
                NONE: 'لا يوجد',
                LOW: 'منخفض',
                MEDIUM: 'متوسط',
                HIGH: 'عالي',
                VERY_HIGH: 'عالي جداً'
            };

            const embed = new EmbedBuilder()
                .setAuthor({
                    name: guild.name, 
                    iconURL: guild.iconURL({ dynamic: true }) || null
                })
                .setColor('#00566b')
                .addFields(
                    {
                        name: '🆔 Server ID', 
                        value: guild.id, 
                        inline: false
                    },
                    {
                        name: '📆 تاريخ الإنشاء', 
                        value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, 
                        inline: false
                    },
                    {
                        name: '👑 المالك', 
                        value: owner ? `<@${owner.id}>` : 'غير معروف', 
                        inline: false
                    },
                    {
                        name: `👥 الأعضاء (${guild.memberCount})`, 
                        value: `**${guild.premiumSubscriptionCount}** Boosts ✨`, 
                        inline: false
                    },
                    {
                        name: `💬 القنوات (${guild.channels.cache.size})`, 
                        value: [
                            `**${guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size}** نص`,
                            `**${guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size}** صوت`,
                            `**${guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size}** فئات`
                        ].join(' | '), 
                        inline: false
                    },
                    {
                        name: '🌍 معلومات أخرى',
                        value: [
                            `**مستوى التحقق:** ${verificationLevels[guild.verificationLevel] || guild.verificationLevel}`,
                            `**الإيموجيات:** ${guild.emojis.cache.size}`,
                            `**الرولات:** ${guild.roles.cache.size}`
                        ].join('\n'),
                        inline: false
                    }
                )
                .setThumbnail(guild.iconURL({ dynamic: true }) || null)
                .setFooter({
                    text: `طلب من قبل: ${interaction.user.username}`,
                    iconURL: interaction.user.displayAvatarURL()
                });

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in server command:', error);
            await interaction.editReply({ 
                content: '❌ حدث خطأ أثناء جلب معلومات السيرفر! يرجى المحاولة لاحقاً.' 
            });
        }
    }
}