const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");
const { Database } = require("st.db");
const reactionDB = new Database("/Json-db/Bots/autoReactionDB.json");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('auto-reaction')
        .setDescription('إدارة التفاعل التلقائي على رسائل القنوات')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addSubcommand(subcommand => subcommand
            .setName('add')
            .setDescription('إضافة قناة/قنوات للتفاعل التلقائي')
            .addChannelOption(option => option
                .setName('channels')
                .setDescription('اختر القنوات المراد تفعيل التفاعل فيها')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText))
            .addStringOption(option => option
                .setName('emoji')
                .setDescription('الإيموجي المطلوب (يجب أن يكون من إيموجيات السيرفر)')
                .setRequired(true)))
        .addSubcommand(subcommand => subcommand
            .setName('remove')
            .setDescription('إزالة قناة/قنوات من التفاعل التلقائي')
            .addChannelOption(option => option
                .setName('channels')
                .setDescription('اختر القنوات المراد إزالتها')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText)))
        .addSubcommand(subcommand => subcommand
            .setName('list')
            .setDescription('عرض القنوات المفعلة')),
    
    async execute(interaction, client) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        // جلب الإعدادات الحالية
        let settings = reactionDB.get(`auto_reaction_${guildId}`) || { channels: {} };

        switch (subcommand) {
            case 'add': {
                const channels = interaction.options.getChannel('channels', true);
                const emoji = interaction.options.getString('emoji', true);

                // التحقق من صحة الإيموجي
                let validEmoji;
                try {
                    validEmoji = interaction.guild.emojis.cache.find(e => e.toString() === emoji) || emoji;
                    if (!validEmoji) throw new Error();
                } catch {
                    return interaction.reply({ content: '❌ **يجب تحديد إيموجي صالح من داخل السيرفر!**', ephemeral: true });
                }

                // إضافة القنوات
                const channelsToAdd = Array.isArray(channels) ? channels : [channels];
                let addedCount = 0;

                channelsToAdd.forEach(channel => {
                    if (!settings.channels[channel.id]) {
                        settings.channels[channel.id] = { emoji: validEmoji.toString() };
                        addedCount++;
                    }
                });

                reactionDB.set(`auto_reaction_${guildId}`, settings);

                return interaction.reply({
                    content: addedCount > 0 
                        ? `✅ **تم تفعيل التفاعل التلقائي في ${addedCount} قناة باستخدام الإيموجي ${validEmoji}**`
                        : 'ℹ️ **القنوات المحددة مفعلة بالفعل!**',
                    ephemeral: true
                });
            }

            case 'remove': {
                const channels = interaction.options.getChannel('channels', true);
                const channelsToRemove = Array.isArray(channels) ? channels : [channels];
                let removedCount = 0;

                channelsToRemove.forEach(channel => {
                    if (settings.channels[channel.id]) {
                        delete settings.channels[channel.id];
                        removedCount++;
                    }
                });

                reactionDB.set(`auto_reaction_${guildId}`, settings);

                return interaction.reply({
                    content: removedCount > 0
                        ? `✅ **تم إزالة ${removedCount} قناة من التفاعل التلقائي**`
                        : 'ℹ️ **القنوات المحددة غير مفعلة بالأصل!**',
                    ephemeral: true
                });
            }

            case 'list': {
                if (Object.keys(settings.channels).length === 0) {
                    return interaction.reply({ content: 'ℹ️ **لا توجد قنوات مفعلة حالياً!**', ephemeral: true });
                }

                const list = Object.entries(settings.channels).map(([id, data]) => {
                    return `• <#${id}> → ${data.emoji}`;
                }).join('\n');

                return interaction.reply({
                    content: `📋 **القنوات المفعلة للتفاعل التلقائي:**\n${list}`,
                    ephemeral: true
                });
            }
        }
    }
};