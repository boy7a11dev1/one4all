const {
    Client,
    Collection,
    PermissionsBitField,
    SlashCommandBuilder,
    discord,
    GatewayIntentBits,
    Partials,
    EmbedBuilder,
    ApplicationCommandOptionType,
    Events,
    ActionRowBuilder,
    ButtonBuilder,
    MessageAttachment,
    ButtonStyle,
    Message
} = require("discord.js");
const { Database } = require("st.db");
const systemDB = new Database("/Json-db/Bots/systemDB.json");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('اعطاء تايم اوت لشخص او ازالته')
        .addUserOption(option =>
            option.setName('member')
                .setDescription('الشخص')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('time')
                .setDescription('الوقت (مثال: 1d, 1h, 1m, 1s)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('السبب')
                .setRequired(false)),

    async execute(interaction) {
        // التحقق من الصلاحيات
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            try {
                await interaction.react("❌");
            } catch {
                return interaction.reply({ content: "❌", ephemeral: true });
            }
            return;
        }

        const member = interaction.options.getMember('member');
        const timeInput = interaction.options.getString('time').toLowerCase();
        const reason = interaction.options.getString('reason') ?? "No reason";

        // تحويل الوقت إلى milliseconds
        function parseTime(input) {
            const match = input.match(/^(\d+)([smhd])$/);
            if (!match) return null;
            const value = parseInt(match[1]);
            const unit = match[2];
            switch (unit) {
                case 's': return value * 1000;
                case 'm': return value * 60 * 1000;
                case 'h': return value * 60 * 60 * 1000;
                case 'd': return value * 24 * 60 * 60 * 1000;
                default: return null;
            }
        }

        const duration = parseTime(timeInput);
        if (!duration || duration <= 0 || duration > 28 * 24 * 60 * 60 * 1000) {
            return interaction.reply({ content: `**صيغة الوقت غير صحيحة أو تتجاوز الحد (28 يوم)**`, ephemeral: true });
        }

        try {
            await member.timeout(duration, reason);

            await interaction.react?.("✅").catch(() => {});
            await interaction.reply({ content: `**تم اعطاء التايم اوت الى ${member} بنجاح**`, ephemeral: true });

            // بعد انتهاء التايم أوت، يرسل رسالة
            setTimeout(() => {
                try {
                    interaction.channel.send(`✅ | تم إسكات ${member} بواسطة ${interaction.user}`);
                } catch (err) {
                    console.error("فشل في إرسال رسالة انتهاء التايم أوت", err);
                }
            }, duration);

        } catch (err) {
            console.error("خطأ في تنفيذ التايم أوت:", err);
            return interaction.reply({
                content: `**الرجاء التحقق من صلاحياتي ثم اعادة المحاولة**`,
                ephemeral: true
            });
        }
    }
};
