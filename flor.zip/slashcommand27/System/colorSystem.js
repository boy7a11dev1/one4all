const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, ComponentType, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require("discord.js");
const { Database } = require("st.db");

// قواعد البيانات
const colorSystemDB = new Database("/Json-db/Bots/colorSystemDB.json");
const colorRolesDB = new Database("/Json-db/Bots/colorRolesDB.json");
const userColorsDB = new Database("/Json-db/Bots/userColorsDB.json");

// متغير لحفظ الجامعين النشطين
const activeCollectors = new Map();

// دالة استعادة الرسائل
async function restoreColorMessages(client) {
    try {
        const allGuilds = colorSystemDB.all();
        
        for (const [key, value] of Object.entries(allGuilds)) {
            if (key.startsWith('color_messages_')) {
                const guildId = key.replace('color_messages_', '');
                const guild = client.guilds.cache.get(guildId);
                if (!guild) continue;
                
                const messages = Array.isArray(value) ? value : [];
                
                for (const msgData of messages) {
                    try {
                        const channel = guild.channels.cache.get(msgData.channel_id);
                        if (!channel) continue;
                        
                        const message = await channel.messages.fetch(msgData.message_id).catch(() => null);
                        if (!message) continue;
                        
                        // إعادة إنشاء جامع الأحداث
                        if (msgData.type === 'buttons') {
                            const collector = message.createMessageComponentCollector({ 
                                componentType: ComponentType.Button, 
                                time: 0,
                                filter: i => i.customId.startsWith('color_btn_')
                            });
                            
                            collector.on('collect', async i => {
                                const colorName = i.customId.replace('color_btn_', '');
                                const response = await handleColorSelection(i, colorName);
                                await i.reply({ content: response, ephemeral: true });
                            });
                            
                            activeCollectors.set(message.id, collector);
                            
                        } else if (msgData.type === 'select_menu') {
                            const collector = message.createMessageComponentCollector({ 
                                componentType: ComponentType.StringSelect, 
                                time: 0,
                                filter: i => i.customId === 'color_select_menu'
                            });
                            
                            collector.on('collect', async i => {
                                const colorName = i.values[0];
                                const response = await handleColorSelection(i, colorName);
                                await i.reply({ content: response, ephemeral: true });
                            });
                            
                            activeCollectors.set(message.id, collector);
                        }
                    } catch (error) {
                        console.error(`Error restoring message ${msgData.message_id}:`, error);
                    }
                }
            }
        }
    } catch (error) {
        console.error('Error in restoreColorMessages:', error);
    }
}

// دالة معالجة اختيار الألوان
async function handleColorSelection(interaction, colorName) {
    try {
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;
        const colorRoles = colorRolesDB.get(`roles_${guildId}`) || {};
        
        const roleId = colorRoles[colorName];
        if (!roleId) return "❌ هذا اللون غير متاح!";

        const member = await interaction.guild.members.fetch(userId);
        const currentColorRoles = Object.values(colorRoles);

        await member.roles.remove(currentColorRoles).catch(() => null);
        await member.roles.add(roleId);
        userColorsDB.set(`user_${userId}_${guildId}`, colorName);
        return `✅ تم تغيير لون رتبتك إلى **${colorName}** بنجاح!`;
    } catch (error) {
        console.error('Error in handleColorSelection:', error);
        return "❌ حدث خطأ أثناء محاولة تغيير اللون!";
    }
}

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('color-system')
        .setDescription('نظام إدارة ألوان الرتب المتكامل')

        .addSubcommand(sub => sub
            .setName('add-color')
            .setDescription('إضافة لون جديد')
            .addStringOption(opt => opt.setName('name').setDescription('اسم اللون (عربي/إنجليزي)').setRequired(true))
            .addRoleOption(opt => opt.setName('role').setDescription('الرتبة المرتبطة باللون').setRequired(true))
            .addStringOption(opt => opt.setName('image').setDescription('رابط صورة اللون (اختياري)').setRequired(false)))

        .addSubcommand(sub => sub
            .setName('remove-color')
            .setDescription('حذف لون موجود')
            .addStringOption(opt => opt.setName('name').setDescription('اسم اللون المراد حذفه').setRequired(true)))

        .addSubcommand(sub => sub
            .setName('show-menu')
            .setDescription('عرض قائمة الألوان مع الأزرار')
            .addStringOption(opt => opt.setName('message').setDescription('رسالة العرض (اختياري)').setRequired(false)))

        .addSubcommand(sub => sub
            .setName('send-panel')
            .setDescription('إرسال بانل الألوان (رسالة عادية)')
            .addStringOption(opt => opt.setName('message').setDescription('النص الذي تريد عرضه').setRequired(true)))

        .addSubcommand(sub => sub
            .setName('convert-to-select')
            .setDescription('تحويل الأزرار إلى قائمة منسدلة')
            .addStringOption(opt => opt.setName('message').setDescription('نص الرسالة (اختياري)').setRequired(false))
            .addStringOption(opt => opt.setName('image').setDescription('رابط صورة (اختياري)').setRequired(false)))

        .addSubcommand(sub => sub
            .setName('change-color')
            .setDescription('تغيير لون رتبتك')
            .addStringOption(opt => opt.setName('color').setDescription('اختر اللون الجديد').setRequired(true)))

        .addSubcommand(sub => sub
            .setName('remove-my-color')
            .setDescription('إزالة لون رتبتك الحالي')),

    // دالة التنفيذ عند تشغيل البوت
    setup: async (client) => {
        activeCollectors.forEach(collector => collector.stop());
        activeCollectors.clear();
        await restoreColorMessages(client);
        console.log('[Color System] تم تحميل النظام واستعادة الرسائل بنجاح');
    },

    async execute(interaction) {
        const subCommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;
        const userId = interaction.user.id;

        const colors = colorSystemDB.get(`colors_${guildId}`) || {};
        const colorRoles = colorRolesDB.get(`roles_${guildId}`) || {};
        const userColor = userColorsDB.get(`user_${userId}_${guildId}`) || null;

        if (["add-color", "remove-color", "send-panel", "convert-to-select"].includes(subCommand)) {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                return interaction.reply({ content: "❌ تحتاج إلى صلاحية إدارة الرتب!", ephemeral: true });
            }
        }

        switch (subCommand) {
            case 'add-color': {
                const name = interaction.options.getString('name');
                const role = interaction.options.getRole('role');
                const image = interaction.options.getString('image');

                colors[name] = { 
                    code: `#${Math.floor(Math.random()*16777215).toString(16)}`, 
                    image: image || null,
                    created_at: new Date().toISOString()
                };
                
                colorSystemDB.set(`colors_${guildId}`, colors);
                colorRoles[name] = role.id;
                colorRolesDB.set(`roles_${guildId}`, colorRoles);

                return interaction.reply({ content: `✅ تم إضافة اللون **${name}** بنجاح!`, ephemeral: true });
            }

            case 'remove-color': {
                const name = interaction.options.getString('name');
                if (!colorRoles[name]) return interaction.reply({ content: "❌ هذا اللون غير موجود!", ephemeral: true });

                delete colors[name];
                delete colorRoles[name];
                colorSystemDB.set(`colors_${guildId}`, colors);
                colorRolesDB.set(`roles_${guildId}`, colorRoles);

                const allUsers = userColorsDB.all();
                for (const [key, value] of Object.entries(allUsers)) {
                    if (value === name && key.includes(guildId)) {
                        userColorsDB.delete(key);
                    }
                }

                return interaction.reply({ content: `✅ تم حذف اللون **${name}** بنجاح`, ephemeral: true });
            }

            case 'show-menu':
            case 'send-panel': {
                if (Object.keys(colorRoles).length === 0) return interaction.reply({ content: "❌ لا توجد ألوان مضافَة بعد!", ephemeral: true });

                const message = interaction.options.getString('message') || "اختر لون الذي تريدة يظهر على اسمك :";
                const buttons = Object.keys(colorRoles).map(name => 
                    new ButtonBuilder()
                        .setCustomId(`color_btn_${name}`)
                        .setLabel(name)
                        .setStyle(ButtonStyle.Primary)
                );
                
                const rows = [];
                for (let i = 0; i < buttons.length; i += 5) {
                    rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
                }

                const msg = await interaction.channel.send({ content: message, components: rows });
                
                const colorMessages = colorSystemDB.get(`color_messages_${guildId}`) || [];
                colorMessages.push({
                    message_id: msg.id,
                    channel_id: msg.channel.id,
                    type: 'buttons',
                    guild_id: guildId,
                    created_at: new Date().toISOString()
                });
                colorSystemDB.set(`color_messages_${guildId}`, colorMessages);

                const collector = msg.createMessageComponentCollector({ 
                    componentType: ComponentType.Button, 
                    time: 0,
                    filter: i => i.customId.startsWith('color_btn_')
                });
                
                collector.on('collect', async i => {
                    const colorName = i.customId.replace('color_btn_', '');
                    const response = await handleColorSelection(i, colorName);
                    await i.reply({ content: response, ephemeral: true });
                });
                
                activeCollectors.set(msg.id, collector);

                return interaction.reply({ content: "✅ تم عرض البانل بنجاح!", ephemeral: true });
            }

            case 'convert-to-select': {
                if (Object.keys(colorRoles).length === 0) return interaction.reply({ content: "❌ لا توجد ألوان مضافَة بعد!", ephemeral: true });

                const message = interaction.options.getString('message') || "اختر لون من القائمة:";
                const image = interaction.options.getString('image');

                const embed = new EmbedBuilder()
                    .setTitle(interaction.guild.name)
                    .setDescription(message)
                    .setColor(0x000f12) // هنا تم تغيير لون الأمبيد إلى #000f12
                    .setTimestamp();

                if (image) embed.setImage(image);

                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('color_select_menu')
                    .setPlaceholder('اختر لونك المفضل')
                    .addOptions(Object.keys(colorRoles).map(name => 
                        new StringSelectMenuOptionBuilder()
                            .setLabel(name)
                            .setValue(name)
                    ));

                const row = new ActionRowBuilder().addComponents(selectMenu);

                const msg = await interaction.channel.send({ 
                    embeds: [embed], 
                    components: [row] 
                });
                
                const colorMessages = colorSystemDB.get(`color_messages_${guildId}`) || [];
                colorMessages.push({
                    message_id: msg.id,
                    channel_id: msg.channel.id,
                    type: 'select_menu',
                    guild_id: guildId,
                    created_at: new Date().toISOString()
                });
                colorSystemDB.set(`color_messages_${guildId}`, colorMessages);

                const collector = msg.createMessageComponentCollector({ 
                    componentType: ComponentType.StringSelect, 
                    time: 0,
                    filter: i => i.customId === 'color_select_menu'
                });
                
                collector.on('collect', async i => {
                    const colorName = i.values[0];
                    const response = await handleColorSelection(i, colorName);
                    await i.reply({ content: response, ephemeral: true });
                });
                
                activeCollectors.set(msg.id, collector);

                return interaction.reply({ content: "✅ تم تحويل الأزرار إلى قائمة بنجاح!", ephemeral: true });
            }

            case 'change-color': {
                const colorName = interaction.options.getString('color');
                if (!colorRoles[colorName]) return interaction.reply({ content: "❌ هذا اللون غير متاح!", ephemeral: true });

                const response = await handleColorSelection(interaction, colorName);
                return interaction.reply({ content: response, ephemeral: true });
            }

            case 'remove-my-color': {
                const member = await interaction.guild.members.fetch(userId);
                const currentColorRoles = Object.values(colorRoles);

                try {
                    await member.roles.remove(currentColorRoles);
                    userColorsDB.delete(`user_${userId}_${guildId}`);
                    return interaction.reply({ content: "✅ تم إزالة لون رتبتك الحالي بنجاح!", ephemeral: true });
                } catch (error) {
                    console.error('Error removing color roles:', error);
                    return interaction.reply({ content: "❌ حدث خطأ أثناء إزالة اللون!", ephemeral: true });
                }
            }
        }
    }
};