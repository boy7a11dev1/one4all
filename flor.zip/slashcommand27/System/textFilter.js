const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");
const systemDB = new Database("/Json-db/Bots/systemDB.json");

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('text-filter')
        .setDescription('إدارة حذف الرسائل النصية تلقائياً')
        .addSubcommand(subcommand => subcommand
            .setName('add')
            .setDescription('إضافة قناة/قنوات لحذف الرسائل النصية')
            .addChannelOption(option => option
                .setName('channels')
                .setDescription('اختر القنوات المراد تطبيق الأمر عليها')
                .setRequired(true)))
        .addSubcommand(subcommand => subcommand
            .setName('remove')
            .setDescription('إزالة قناة/قنوات من القائمة')
            .addChannelOption(option => option
                .setName('channels')
                .setDescription('اختر القنوات المراد إزالتها من القائمة')
                .setRequired(true)))
        .addSubcommand(subcommand => subcommand
            .setName('list')
            .setDescription('عرض القنوات المفعلة')),
    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        try {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
                return interaction.reply({ content: `**⚠️ لا تمتلك صلاحية إدارة الرسائل**`, ephemeral: true });
            }

            const subcommand = interaction.options.getSubcommand();
            const channels = interaction.options.getChannel('channels');

            // الحصول على الإعدادات الحالية
            let settings = systemDB.get(`text_filter_${interaction.guild.id}`) || {
                enabledChannels: []
            };

            switch (subcommand) {
                case 'add': {
                    const channelsToAdd = Array.isArray(channels) ? channels : [channels];
                    const addedChannels = [];

                    channelsToAdd.forEach(channel => {
                        if (!settings.enabledChannels.includes(channel.id)) {
                            settings.enabledChannels.push(channel.id);
                            addedChannels.push(channel.toString());
                        }
                    });

                    systemDB.set(`text_filter_${interaction.guild.id}`, settings);

                    if (addedChannels.length > 0) {
                        await interaction.reply({
                            content: `**✅ تم تفعيل حذف الرسائل النصية في:**\n${addedChannels.join('\n')}\n\nسيتم حذف الرسائل النصية والسماح بالصور والفيديوهات فقط`,
                            ephemeral: true
                        });
                    } else {
                        await interaction.reply({
                            content: `**ℹ️ القنوات المحددة مفعلة بالفعل**`,
                            ephemeral: true
                        });
                    }
                    break;
                }

                case 'remove': {
                    const channelsToRemove = Array.isArray(channels) ? channels : [channels];
                    const removedChannels = [];

                    channelsToRemove.forEach(channel => {
                        const index = settings.enabledChannels.indexOf(channel.id);
                        if (index !== -1) {
                            settings.enabledChannels.splice(index, 1);
                            removedChannels.push(channel.toString());
                        }
                    });

                    systemDB.set(`text_filter_${interaction.guild.id}`, settings);

                    if (removedChannels.length > 0) {
                        await interaction.reply({
                            content: `**✅ تم تعطيل حذف الرسائل النصية في:**\n${removedChannels.join('\n')}`,
                            ephemeral: true
                        });
                    } else {
                        await interaction.reply({
                            content: `**ℹ️ القنوات المحددة غير مفعلة بالأصل**`,
                            ephemeral: true
                        });
                    }
                    break;
                }

                case 'list': {
                    if (settings.enabledChannels.length === 0) {
                        return interaction.reply({
                            content: `**ℹ️ لا توجد قنوات مفعلة حالياً**`,
                            ephemeral: true
                        });
                    }

                    const channelList = settings.enabledChannels.map(id => `<#${id}>`).join('\n');
                    await interaction.reply({
                        content: `**📋 القنوات المفعلة لحذف الرسائل النصية:**\n${channelList}`,
                        ephemeral: true
                    });
                    break;
                }
            }
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: `**❌ حدث خطأ أثناء تنفيذ الأمر**`,
                ephemeral: true
            });
        }
    }
}