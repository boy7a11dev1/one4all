const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { Database } = require("st.db");
const systemDB = new Database("./Json-db/Bots/systemDB.json"); // Fixed path
const axios = require("axios");

// Initialize database with secure approach
function initializeDatabase(clientId) {
  if (!systemDB.has("one4all")) {
    systemDB.set("one4all", [{
      clientId: clientId,
      token: process.env.BOT_TOKEN || "MTM2NzA5NzUzMzQ1MjUyMTQ5Mg.GAqkyJ.3kGsEVXLTpKHPiMG4LPSHdV5bPgYU3YFWFn-C0" // Use environment variable
    }]);
    console.log("تم تهيئة قاعدة البيانات بالبيانات الأساسية");
  }
}

module.exports = {
    ownersOnly: false,
    data: new SlashCommandBuilder()
        .setName('banner')
        .setDescription('عرض بانر العضو')
        .addUserOption(option => option
            .setName('user')
            .setDescription('العضو المراد عرض بانره')
            .setRequired(false)),
    
    async execute(interaction) {
        await interaction.deferReply();
        initializeDatabase(interaction.client.user.id); // Pass current bot's ID
        
        try {
            const user = interaction.options.getUser('user') || interaction.user;
            const tokensData = systemDB.get('one4all');
            
            if (!tokensData || tokensData.length === 0) {
                throw new Error("لا توجد بيانات توكن في قاعدة البيانات");
            }

            const botData = tokensData.find(a => a.clientId === interaction.client.user.id);
            
            if (!botData) {
                throw new Error("بيانات البوت غير موجودة في قاعدة البيانات");
            }
            
            if (!botData.token) {
                throw new Error("توكن البوت غير موجود في قاعدة البيانات");
            }

            const response = await axios.get(`https://discord.com/api/v10/users/${user.id}`, {
                headers: { 
                    Authorization: `Bot ${botData.token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data.banner) {
                return await interaction.editReply({ 
                    content: `❌ هذا المستخدم ليس لديه بانر!` 
                });
            }

            const extension = response.data.banner.startsWith('a_') ? 'gif' : 'png';
            const bannerURL = `https://cdn.discordapp.com/banners/${user.id}/${response.data.banner}.${extension}?size=4096`;

            const embed = new EmbedBuilder()
                .setTitle(`بانر ${user.username}`)
                .setImage(bannerURL)
                .setColor('#00566b');

            await interaction.editReply({ embeds: [embed] });
            
        } catch (error) {
            console.error("حدث خطأ:", error);
            await interaction.editReply({ 
                content: `❌ خطأ: ${error.message} | يرجى التواصل مع المطورين` 
            });
        }
    }
}