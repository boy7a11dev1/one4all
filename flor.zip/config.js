// filepath: c:\Users\yousif\Desktop\test2\config.js
require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN, // Updated to match the .env key
  prefix: "!",
  owner: "1270175467206611049"
};